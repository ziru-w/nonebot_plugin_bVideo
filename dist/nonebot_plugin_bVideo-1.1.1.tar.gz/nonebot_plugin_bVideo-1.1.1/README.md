# nonebot_plugin_bVideo
一个基于NoneBot2的插件，用于处理推送B站up主最新视频的插件


A NoneBot2-based plugin for processing plugins that push the latest videos of the B station up master


下载方法 pip install nonebot_plugin_bVideo


/收录B站UP 个人空间链接 不要链接里?以后的部分 用于收录B站UP的mid，形如/收录B站UP https://space.bilibili.com/688379639

/推送b站 返回收录的前6个up的视频标题加链接

/添加B站推送 up主名字 /删除B站推送 up主名字 群聊发推送到该群，私聊推送到发送者 名字允许不一样，但只返回第一个包含结果，所以请尽量一样
